package controlador;

import modelo.Estudiante;
import dao.EstudianteDAO;
import java.util.List;

public class EstudianteController {
    private EstudianteDAO estudianteDAO;

    public EstudianteController() {
        estudianteDAO = new EstudianteDAO();
    }

    public List<Estudiante> listarEstudiantes() {
        return estudianteDAO.obtenerTodos();
    }

    public boolean agregarEstudiante(Estudiante estudiante) {
        return estudianteDAO.guardar(estudiante);
    }

    public boolean actualizarEstudiante(Estudiante estudiante) {
        return estudianteDAO.actualizar(estudiante);
    }

    public boolean eliminarEstudiante(int id) {
        return estudianteDAO.eliminar(id);
    }
}
