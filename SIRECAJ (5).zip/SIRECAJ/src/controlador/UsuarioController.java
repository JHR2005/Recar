package controlador;

import dao.UsuarioDAO;

public class UsuarioController {
    private UsuarioDAO usuarioDAO;

    public UsuarioController() {
        usuarioDAO = new UsuarioDAO();
    }

    public boolean login(String usuario, String clave) {
        return usuarioDAO.validarUsuario(usuario, clave);
    }
}
