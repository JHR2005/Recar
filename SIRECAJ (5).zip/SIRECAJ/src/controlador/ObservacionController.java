package controlador;

import dao.ObservacionDAO;

public class ObservacionController {
    private ObservacionDAO observacionDAO;

    public ObservacionController() {
        observacionDAO = new ObservacionDAO();
    }

    public boolean guardarObservacion(String texto) {
        return observacionDAO.guardarObservacion(texto);
    }
}
