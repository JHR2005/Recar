package dao;

import conexion.ConexionSQL;
import modelo.Observacion;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ObservacionDAO {
    public static boolean insertar(Observacion obs) {
        String sql = "INSERT INTO Observaciones (estudiante_id, tipo, descripcion, fecha) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionSQL.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, obs.getEstudianteId());
            stmt.setString(2, obs.getTipo());
            stmt.setString(3, obs.getDescripcion());
            stmt.setDate(4, java.sql.Date.valueOf(obs.getFecha()));

            int filas = stmt.executeUpdate();
            return filas > 0;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar observación: " + e.getMessage());
            return false;
        }
    }
}
