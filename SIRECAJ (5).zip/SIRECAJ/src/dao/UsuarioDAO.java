package dao;

import conexion.ConexionSQL;
import modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {
    public Usuario validarLogin(String usuario, String clave) {
        Usuario user = null;
        String sql = "SELECT * FROM Usuarios WHERE usuario = ? AND clave = ?";

        try (Connection con = ConexionSQL.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, clave);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new Usuario();
                user.setId(rs.getInt("id"));
                user.setUsuario(rs.getString("usuario"));
                user.setClave(rs.getString("clave"));
                user.setRol(rs.getString("rol"));
            }

        } catch (Exception e) {
            System.out.println("❌ Error al validar usuario: " + e.getMessage());
        }
        return user;
    }
}