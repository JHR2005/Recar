package dao;

import conexion.ConexionSQL;
import modelo.Nota;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class NotaDAO {

    public boolean insertar(Nota nota) {
        String sql = "INSERT INTO Notas (estudiante_id, curso, bimestre, nota) VALUES (?, ?, ?, ?)";

        try (Connection con = ConexionSQL.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nota.getEstudianteId());
            ps.setString(2, nota.getCurso());
            ps.setInt(3, nota.getBimestre());
            ps.setFloat(4, nota.getNota());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
