package dao;

import conexion.ConexionSQL;
import modelo.Estudiante;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstudianteDAO {

    public static List<Estudiante> listar() {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "SELECT * FROM Estudiantes";

        try (Connection con = ConexionSQL.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Estudiante est = new Estudiante();
                est.setId(rs.getInt("id"));
                est.setNombre(rs.getString("nombre"));
                est.setGrado(rs.getString("grado"));
                est.setSeccion(rs.getString("seccion"));
                lista.add(est);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al listar estudiantes: " + e.getMessage());
        }

        return lista;
    }

    public static boolean insertar(Estudiante est) {
        String sql = "INSERT INTO Estudiantes (nombre, grado, seccion) VALUES (?, ?, ?)";

        try (Connection con = ConexionSQL.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, est.getNombre());
            stmt.setString(2, est.getGrado());
            stmt.setString(3, est.getSeccion());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("❌ Error al registrar estudiante: " + e.getMessage());
            return false;
        }
    }
}
