package dao;

import conexion.ConexionSQL;
import modelo.Asistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AsistenciaDAO {
    public static boolean insertar(Asistencia a) {
        String sql = "INSERT INTO Asistencias (estudiante_id, fecha, presente) VALUES (?, ?, ?)";

        try (Connection con = ConexionSQL.getConnection();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, a.getEstudianteId());
            stmt.setDate(2, java.sql.Date.valueOf(a.getFecha()));
            stmt.setBoolean(3, a.isPresente());

            int filas = stmt.executeUpdate();
            return filas > 0;

        } catch (Exception e) {
            System.out.println("❌ Error al insertar asistencia: " + e.getMessage());
            return false;
        }
    }
}