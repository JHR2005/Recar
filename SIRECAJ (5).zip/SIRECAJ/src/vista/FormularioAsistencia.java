package vista;

import dao.EstudianteDAO;
import modelo.Estudiante;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class FormularioAsistencia extends JFrame {
    public FormularioAsistencia() {
        setTitle("Registrar Asistencia");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JComboBox<Estudiante> estudianteBox = new JComboBox<>();
        for (Estudiante est : EstudianteDAO.listar()) {
            estudianteBox.addItem(est);
        }

        JCheckBox presenteBox = new JCheckBox("¿Presente?");
        JTextField fechaField = new JTextField(LocalDate.now().toString());

        JButton registrarBtn = new JButton("Registrar");
        registrarBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "✔ Asistencia registrada (simulado)");
            dispose();
        });

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(estudianteBox);
        panel.add(presenteBox);
        panel.add(fechaField);
        panel.add(registrarBtn);

        add(panel);
    }
}
