package vista;

import dao.EstudianteDAO;
import dao.NotaDAO;
import modelo.Estudiante;
import modelo.Nota;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FormularioHistorialNotasPorEstudiante extends JFrame {

    private JComboBox<Estudiante> cbEstudiantes;
    private JTable tabla;
    private DefaultTableModel modelo;

    public FormularioHistorialNotasPorEstudiante() {
        setTitle("Historial de Notas por Estudiante");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel superior con el combo
        JPanel panelSuperior = new JPanel(new FlowLayout());
        panelSuperior.add(new JLabel("Seleccionar estudiante:"));

        cbEstudiantes = new JComboBox<>();
        cargarEstudiantes();
        panelSuperior.add(cbEstudiantes);

        JButton btnBuscar = new JButton("Ver Notas");
        panelSuperior.add(btnBuscar);

        add(panelSuperior, BorderLayout.NORTH);

        // Tabla
        modelo = new DefaultTableModel(new String[]{"ID", "Curso", "Bimestre", "Nota"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll, BorderLayout.CENTER);

        // Acción del botón
        btnBuscar.addActionListener(e -> mostrarNotas());

        setVisible(true);
    }

    private void cargarEstudiantes() {
        EstudianteDAO dao = new EstudianteDAO();
        List<Estudiante> lista = dao.obtenerTodosLosEstudiantes();
        for (Estudiante est : lista) {
            cbEstudiantes.addItem(est);
        }
    }

    private void mostrarNotas() {
        modelo.setRowCount(0); // Limpiar tabla

        Estudiante estudiante = (Estudiante) cbEstudiantes.getSelectedItem();
        if (estudiante != null) {
            NotaDAO dao = new NotaDAO();
            List<Nota> notas = dao.obtenerNotasPorEstudiante(estudiante.getId());

            for (Nota nota : notas) {
                modelo.addRow(new Object[]{
                    nota.getId(),
                    nota.getCurso(),
                    nota.getBimestre(),
                    nota.getNota()
                });
            }

            if (notas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Este estudiante no tiene notas registradas.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FormularioHistorialNotasPorEstudiante::new);
    }
}
