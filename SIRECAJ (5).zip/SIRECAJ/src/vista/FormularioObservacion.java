package vista;

import dao.EstudianteDAO;
import dao.ObservacionDAO;
import modelo.Estudiante;
import modelo.Observacion;

import javax.swing.*;
import java.util.List;

public class FormularioObservacion extends JFrame {

    public FormularioObservacion() {
        setTitle("Registrar Observación");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Mostrar mensaje de ayuda al abrir el formulario
        JOptionPane.showMessageDialog(this,
                "📝 Instrucciones:\n\n" +
                "1. Selecciona el estudiante.\n" +
                "2. Especifica el tipo de observación (académica, emocional, etc).\n" +
                "3. Escribe una descripción clara (máx. 500 caracteres).\n" +
                "4. Selecciona la fecha.",
                "Instrucciones para el registro",
                JOptionPane.INFORMATION_MESSAGE
        );

        JComboBox<String> estudianteCombo = new JComboBox<>();
        JTextField tipoField = new JTextField(20);
        JTextArea descripcionArea = new JTextArea(5, 20);
        JTextField fechaField = new JTextField("YYYY-MM-DD");

        // Llenar estudiantes
        EstudianteDAO estudianteDAO = new EstudianteDAO();
        List<Estudiante> estudiantes = estudianteDAO.listar();
        for (Estudiante est : estudiantes) {
            estudianteCombo.addItem(est.getId() + " - " + est.getNombre());
        }

        JButton guardarBtn = new JButton("Guardar");
        guardarBtn.addActionListener(e -> {
            try {
                int estudianteId = Integer.parseInt(estudianteCombo.getSelectedItem().toString().split(" - ")[0]);
                String tipo = tipoField.getText();
                String descripcion = descripcionArea.getText();
                String fecha = fechaField.getText();

                if (tipo.isEmpty() || descripcion.isEmpty() || fecha.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "❌ Todos los campos son obligatorios.");
                    return;
                }

                Observacion obs = new Observacion();
                obs.setEstudianteId(estudianteId);
                obs.setTipo(tipo);
                obs.setDescripcion(descripcion);
                obs.setFecha(fecha);

                ObservacionDAO dao = new ObservacionDAO();
                boolean ok = dao.insertar(obs);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "✔ Observación registrada correctamente.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Error al guardar.");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Estudiante:"));
        panel.add(estudianteCombo);
        panel.add(new JLabel("Tipo:"));
        panel.add(tipoField);
        panel.add(new JLabel("Descripción:"));
        panel.add(new JScrollPane(descripcionArea));
        panel.add(new JLabel("Fecha:"));
        panel.add(fechaField);
        panel.add(guardarBtn);

        add(panel);
    }
}
