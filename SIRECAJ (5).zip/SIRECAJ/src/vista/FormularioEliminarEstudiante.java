package vista;

import dao.EstudianteDAO;
import modelo.Estudiante;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FormularioEliminarEstudiante extends JFrame {
    private JComboBox<Estudiante> comboEstudiantes;
    private JButton btnEliminar;

    public FormularioEliminarEstudiante() {
        setTitle("Eliminar Estudiante");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        comboEstudiantes = new JComboBox<>();
        cargarEstudiantes();

        btnEliminar = new JButton("Eliminar Estudiante");
        btnEliminar.addActionListener(e -> eliminarEstudiante());

        JPanel panel = new JPanel(new GridLayout(2, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(comboEstudiantes);
        panel.add(btnEliminar);

        add(panel, BorderLayout.CENTER);
    }

    private void cargarEstudiantes() {
        EstudianteDAO dao = new EstudianteDAO();
        List<Estudiante> lista = dao.obtenerTodosLosEstudiantes();

        comboEstudiantes.removeAllItems();
        for (Estudiante est : lista) {
            comboEstudiantes.addItem(est);
        }
    }

    private void eliminarEstudiante() {
        Estudiante seleccionado = (Estudiante) comboEstudiantes.getSelectedItem();

        if (seleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un estudiante.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro que desea eliminar a " + seleccionado.getNombre() + "?",
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            EstudianteDAO dao = new EstudianteDAO();
            dao.eliminar(seleccionado.getId());
            JOptionPane.showMessageDialog(this, "Estudiante eliminado.");
            cargarEstudiantes(); // refrescar lista
        }
    }
}
