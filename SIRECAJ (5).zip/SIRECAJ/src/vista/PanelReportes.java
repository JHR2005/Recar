package vista;

import javax.swing.*;
import java.awt.*;

public class PanelReportes extends JPanel {
    public PanelReportes() {
        setLayout(new BorderLayout());
        JLabel titulo = new JLabel("Reportes del Sistema", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        JTextArea area = new JTextArea("Aquí se mostrarán los reportes generados...");
        add(new JScrollPane(area), BorderLayout.CENTER);
    }
}