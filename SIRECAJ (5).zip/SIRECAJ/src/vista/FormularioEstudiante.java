package vista;

import dao.EstudianteDAO;
import modelo.Estudiante;

import javax.swing.*;
import java.awt.*;

public class FormularioEstudiante extends JFrame {

    public FormularioEstudiante() {
        setTitle("Registrar Estudiante");
        setSize(300, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JTextField nombreField = new JTextField();
        JTextField gradoField = new JTextField();
        JTextField seccionField = new JTextField();

        JButton guardarBtn = new JButton("Guardar");
        guardarBtn.addActionListener(e -> {
            String nombre = nombreField.getText();
            String grado = gradoField.getText();
            String seccion = seccionField.getText();

            if (nombre.isEmpty() || grado.isEmpty() || seccion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠ Todos los campos son obligatorios.");
                return;
            }

            Estudiante est = new Estudiante(nombre, grado, seccion);
            boolean exito = EstudianteDAO.insertar(est);

            if (exito) {
                JOptionPane.showMessageDialog(this, "✔ Estudiante registrado.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Error al registrar estudiante.");
            }
        });

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Grado:"));
        panel.add(gradoField);
        panel.add(new JLabel("Sección:"));
        panel.add(seccionField);
        panel.add(guardarBtn);

        add(panel);
    }
}
