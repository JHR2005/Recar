package vista;

import dao.NotaDAO;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class VistaNotas extends JFrame {

    public VistaNotas() {
        setTitle("Lista de Notas");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JTextArea areaNotas = new JTextArea();
        areaNotas.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(areaNotas);
        add(scrollPane, BorderLayout.CENTER);

        try {
            NotaDAO notaDAO = new NotaDAO();
            List<String> notas = notaDAO.listarConNombreEstudiante();

            if (notas.isEmpty()) {
                areaNotas.setText("⚠ No hay notas registradas.");
            } else {
                StringBuilder sb = new StringBuilder();
                for (String linea : notas) {
                    sb.append(linea).append("\n");
                }
                areaNotas.setText(sb.toString());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al cargar notas: " + e.getMessage());
        }
    }
}
