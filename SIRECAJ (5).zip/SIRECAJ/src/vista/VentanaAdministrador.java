package vista;

import javax.swing.*;

public class VentanaAdministrador extends JFrame {
    public VentanaAdministrador() {
        setTitle("Panel del Administrador");
        setSize(600, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();

        JButton asistenciaBtn = new JButton("Registrar Asistencia");
        asistenciaBtn.addActionListener(e -> new FormularioAsistencia().setVisible(true));

        JButton observacionBtn = new JButton("Registrar Observación");
        observacionBtn.addActionListener(e -> new FormularioObservacion().setVisible(true));

        JButton notaBtn = new JButton("Registrar Nota");
        notaBtn.addActionListener(e -> new FormularioNota().setVisible(true));

        JButton estudianteBtn = new JButton("Registrar Estudiante");
        estudianteBtn.addActionListener(e -> new FormularioEstudiante().setVisible(true));
panel.add(estudianteBtn);

 
        panel.add(asistenciaBtn);
        panel.add(observacionBtn);
        panel.add(notaBtn);
       

        add(panel);
    }
}