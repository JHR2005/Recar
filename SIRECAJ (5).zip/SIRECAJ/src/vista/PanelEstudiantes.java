package vista;

import javax.swing.*;
import java.awt.*;

public class PanelEstudiantes extends JPanel {
    public PanelEstudiantes() {
        setLayout(new BorderLayout());
        JLabel titulo = new JLabel("Gestión de Estudiantes", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        JTextArea area = new JTextArea("Aquí se mostrarán los estudiantes...");
        add(new JScrollPane(area), BorderLayout.CENTER);
    }
}