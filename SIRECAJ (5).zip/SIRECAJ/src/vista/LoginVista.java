package vista;

import dao.UsuarioDAO;
import modelo.Usuario;

import javax.swing.*;

public class LoginVista extends JFrame {

    public LoginVista() {
        setTitle("Login SIRECAJ");
        setSize(300, 180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTextField usuarioField = new JTextField(12);
        JPasswordField claveField = new JPasswordField(12);
        JButton loginBtn = new JButton("Ingresar");

        loginBtn.addActionListener(e -> {
            String usuario = usuarioField.getText();
            String clave = new String(claveField.getPassword());

            UsuarioDAO dao = new UsuarioDAO();
            Usuario usuarioValidado = dao.validarLogin(usuario, clave);

            if (usuarioValidado != null) {
                JOptionPane.showMessageDialog(this, "✔ Bienvenido " + usuarioValidado.getUsuario() + " (" + usuarioValidado.getRol() + ")");
                 new VentanaAdministrador().setVisible(true);  // 👈 abrir nueva ventana
                dispose();
                switch (usuarioValidado.getRol().toLowerCase()) {
                    case "administrador":
                        new VentanaAdministrador().setVisible(true);
                        break;
                    default:
                        JOptionPane.showMessageDialog(this, "⚠ Rol no implementado: " + usuarioValidado.getRol());
                        break;
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Usuario o clave incorrectos");
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Usuario:"));
        panel.add(usuarioField);
        panel.add(new JLabel("Clave:"));
        panel.add(claveField);
        panel.add(loginBtn);

        add(panel);
    }

    public static void main(String[] args) {
        new LoginVista().setVisible(true);
    }
}