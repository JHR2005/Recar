package vista;

import javax.swing.*;

public class VentanaPrincipal extends JFrame {
    public VentanaPrincipal() {
        setTitle("Sistema Principal");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        try {
            JTabbedPane paneles = new JTabbedPane();
            paneles.addTab("Estudiantes", new PanelEstudiantes());
            paneles.addTab("Observaciones", new PanelObservaciones());
            paneles.addTab("Reportes", new PanelReportes());

            add(paneles);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los paneles: " + e.getMessage());
        }
    }
}

