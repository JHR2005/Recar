package vista;

import dao.EstudianteDAO;
import dao.NotaDAO;
import modelo.Estudiante;
import modelo.Nota;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FormularioNota extends JFrame {

    public FormularioNota() {
        setTitle("Registrar Nota");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        EstudianteDAO estudianteDAO = new EstudianteDAO();
        List<Estudiante> estudiantes = estudianteDAO.listar();

        JComboBox<Estudiante> comboEstudiantes = new JComboBox<>();
        for (Estudiante e : estudiantes) {
            comboEstudiantes.addItem(e);
        }

        JTextField cursoField = new JTextField(20);
        JTextField bimestreField = new JTextField(5);
        JTextField notaField = new JTextField(5);

        JButton btnRegistrar = new JButton("Registrar");

        btnRegistrar.addActionListener(e -> {
            Estudiante seleccionado = (Estudiante) comboEstudiantes.getSelectedItem();
            String curso = cursoField.getText().trim();
            String bimestreStr = bimestreField.getText().trim();
            String notaStr = notaField.getText().trim();

            // Validaciones
            if (seleccionado == null || curso.isEmpty() || bimestreStr.isEmpty() || notaStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠ Por favor, complete todos los campos.");
                return;
            }

            try {
                int bimestre = Integer.parseInt(bimestreStr);
                float nota = (float) Double.parseDouble(notaStr); // conversión segura

                if (bimestre < 1 || bimestre > 4) {
                    JOptionPane.showMessageDialog(this, "⚠ El bimestre debe estar entre 1 y 4.");
                    return;
                }

                if (nota < 0 || nota > 20) {
                    JOptionPane.showMessageDialog(this, "⚠ La nota debe estar entre 0 y 20.");
                    return;
                }

                Nota nuevaNota = new Nota(0, seleccionado.getId(), curso, bimestre, nota);
                NotaDAO notaDAO = new NotaDAO();

                if (notaDAO.insertar(nuevaNota)) {
                    JOptionPane.showMessageDialog(this, "✔ Nota registrada exitosamente.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Error al registrar la nota.");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "❌ Formato de número inválido.");
            }
        });

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Estudiante:"));
        panel.add(comboEstudiantes);
        panel.add(new JLabel("Curso:"));
        panel.add(cursoField);
        panel.add(new JLabel("Bimestre (1-4):"));
        panel.add(bimestreField);
        panel.add(new JLabel("Nota (0-20):"));
        panel.add(notaField);
        panel.add(new JLabel());
        panel.add(btnRegistrar);

        add(panel);
    }
}
