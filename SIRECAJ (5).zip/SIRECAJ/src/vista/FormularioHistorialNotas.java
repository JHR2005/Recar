package vista;

import dao.NotaDAO;
import modelo.Nota;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FormularioHistorialNotas extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public FormularioHistorialNotas() {
        setTitle("Historial General de Notas");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        modelo = new DefaultTableModel(new String[]{"ID", "Estudiante ID", "Curso", "Bimestre", "Nota"}, 0);
        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        add(scroll, BorderLayout.CENTER);

        cargarDatos();
        setVisible(true);
    }

    private void cargarDatos() {
        NotaDAO dao = new NotaDAO();
        List<Nota> lista = dao.obtenerTodasLasNotas();

        for (Nota nota : lista) {
            modelo.addRow(new Object[]{
                nota.getId(),
                nota.getEstudianteId(),
                nota.getCurso(),
                nota.getBimestre(),
                nota.getNota()
            });
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FormularioHistorialNotas::new);
    }
}
