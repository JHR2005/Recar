package vista;

import javax.swing.*;
import java.awt.*;

public class PanelObservaciones extends JPanel {
    public PanelObservaciones() {
        setLayout(new BorderLayout());
        JLabel titulo = new JLabel("Observaciones de los Estudiantes", JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(titulo, BorderLayout.NORTH);

        JTextArea area = new JTextArea("Observaciones registradas...");
        add(new JScrollPane(area), BorderLayout.CENTER);
    }
}