package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSQL {
    private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=SIRECAJ_DB;encrypt=true;trustServerCertificate=true";
    private static final String USER = "sa";
    private static final String PASS = "admin123";

    public static Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection connection = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("✔ Conexión exitosa a SQL Server");
            return connection;
        } catch (ClassNotFoundException e) {
            System.out.println("❌ Error: Driver no encontrado -> " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("❌ Error de conexión -> " + e.getMessage());
        }
        return null;
    }
}