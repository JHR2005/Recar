package modelo;

import java.time.LocalDate;

public class Observacion {
    private int id;
    private int estudianteId;
    private String tipo;
    private String descripcion;
    private LocalDate fecha;

    public Observacion() {}

    public Observacion(int estudianteId, String tipo, String descripcion, LocalDate fecha) {
        this.estudianteId = estudianteId;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.fecha = fecha;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}
