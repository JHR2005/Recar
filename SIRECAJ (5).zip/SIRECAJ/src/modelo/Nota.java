package modelo;

public class Nota {
    private int id;
    private int estudianteId;
    private String curso;
    private int bimestre;
    private float nota;

    public Nota() {
    }

    public Nota(int id, int estudianteId, String curso, int bimestre, float nota) {
        this.id = id;
        this.estudianteId = estudianteId;
        this.curso = curso;
        this.bimestre = bimestre;
        this.nota = nota;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEstudianteId() {
        return estudianteId;
    }

    public void setEstudianteId(int estudianteId) {
        this.estudianteId = estudianteId;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getBimestre() {
        return bimestre;
    }

    public void setBimestre(int bimestre) {
        this.bimestre = bimestre;
    }

    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }

    @Override
    public String toString() {
        return "Nota{" +
                "id=" + id +
                ", estudianteId=" + estudianteId +
                ", curso='" + curso + '\'' +
                ", bimestre=" + bimestre +
                ", nota=" + nota +
                '}';
    }
}
