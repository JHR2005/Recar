package modelo;

public class Estudiante {
    private int id;
    private String nombre;
    private String grado;
    private String seccion;

    public Estudiante() {}

    public Estudiante(String nombre, String grado, String seccion) {
        this.nombre = nombre;
        this.grado = grado;
        this.seccion = seccion;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getGrado() { return grado; }
    public void setGrado(String grado) { this.grado = grado; }

    public String getSeccion() { return seccion; }
    public void setSeccion(String seccion) { this.seccion = seccion; }

    @Override
    public String toString() {
        return nombre + " (" + grado + "-" + seccion + ")";
    }
}
