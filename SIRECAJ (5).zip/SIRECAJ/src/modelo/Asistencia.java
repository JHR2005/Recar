package modelo;

import java.time.LocalDate;

public class Asistencia {
    private int id;
    private int estudianteId;
    private LocalDate fecha;
    private boolean presente;

    public Asistencia() {}

    public Asistencia(int estudianteId, LocalDate fecha, boolean presente) {
        this.estudianteId = estudianteId;
        this.fecha = fecha;
        this.presente = presente;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public boolean isPresente() { return presente; }
    public void setPresente(boolean presente) { this.presente = presente; }
}